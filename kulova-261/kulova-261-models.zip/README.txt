Kulova 261 v7. Provisional reconstruction; three entrance steps are a hypothesis. Online process and QA: https://grafitctu.github.io/most/kulova-261/
